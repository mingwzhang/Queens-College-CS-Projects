README - Homework 1  
--------------------

Team: Mingwei Zhang

1. What problems did you finish?
- Problem 1: Distance Matrix (loop and vectorized implementations)
- Problem 2: Correlation Matrix (loop and vectorized implementations)
- Problem 3: Experiments with three sklearn datasets (Iris, Breast Cancer, Digits), including timing results and performance comparison

2. What platform did you use?
- Windows 11

3. Resources that helped me:
- https://numpy.org/learn/
- Homework example files (EntropyComputation.py, ComputeMatrices.py)
- Class lecture materials and notes
